const express = require("express");
const bcrypt = require("bcrypt");
const prisma = require("../prisma/prisma");
const jwt = require("jsonwebtoken");
const validateEmployee = require("../Model/Employee");
const { relativeTimeRounding } = require("moment-timezone");
const router = express.Router();

// Create Employee
router.post("/create-employee", async (req, res) => {
  try {
    const {
      firstName,
      middleName,
      lastName,
      email,
      phoneNumber,
      password,
      region,
      city,
      emergencyContactName,
      emergencyContactPhone,
      idCard,
      profilePicture,
      shiftId,
      bankAccountNumber,
      monthlySalary,
      position,
    } = req.body;
    const { error } = validateEmployee(req.body);
    if (error) {
      return res.status(400).send(error.details[0].message);
    }
    const hasedPassword = await bcrypt.hash(password, 10);
    const emails = await prisma.employee.findUnique({ where: { email } });
    if (emails) {
      return res.status(400).json({ error: "Email Already Registered!" });
    }
    const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
    if (!shift) {
      return res.status(404).json({ error: "Shif Not Found!" });
    }
    const positions = await prisma.position.findUnique({
      where: { id: position },
    });
    if (!position) {
      return res.status(404).json({ error: "Position Not Found" });
    }
    await prisma.employee.create({
      data: {
        firstName,
        middleName,
        lastName,
        email,
        phoneNumber,
        password: hasedPassword,
        region,
        city,
        emergencyContactName,
        emergencyContactPhone,
        idCard,
        profilePicture,
        shiftId,
        bankAccountNumber,
        monthlySalary,
        positionId: position,
      },
    });
    res.status(201).json({ message: "Employee Created Successfully!" });
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
    console.log(error);
  }
});

module.exports = router;
